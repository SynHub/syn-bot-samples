﻿namespace PizzaBot
{
    public static class ActionName
    {
        public const string ToppingsAgain = nameof(ToppingsAgain);

        public const string CouponStart = nameof(CouponStart);
        public const string CouponAgain = nameof(CouponAgain);
        public const string AddressRequest = nameof(AddressRequest);
    }
}